# Telecaller User Guide: A Day in the Life (Ultimate Edition)

Welcome to the Telecaller Portal! This guide contains absolutely **every single feature, shortcut, and automation** available to you. It is written exactly in the order of a typical workday. Follow these steps from the moment you sit at your desk to the moment you leave.

## Step 1: The Morning Check-In (And Goal Setting)
When you first open the app and log in for the day, you will be instantly greeted by the **Daily Welcome Modal**.
1. **View the Top Performer:** The pop-up will show you who the current *Top Performer of the Month* is (e.g., "John Doe - ₹5,000,000"), complete with their total disbursed amount and a highly-visible floating flower animation to celebrate them.
2. **Set Your Intention:** The system greets you by name ("Good Morning, [Your Name]!☀️"). At the bottom, it asks: *"Who will be the next Top Performer?"* Enter your name (or a colleague's) into the text box and click **"Let's Go! 🚀"** to officially start your day.
3. **Mark Your Attendance:** Close the modal and head to the **Attendance** widget on your Dashboard (or navigate to `/telecaller/attendance` in the sidebar).
4. **Clock In Securely:** Click the big **"Check In Now"** button. This opens a confirmation modal where you can type an optional "Good Morning" text note. If your browser asks for Location permissions, you must click **Allow**. Click **Confirm Check In** to officially start your shift.
   - **Crucial Feature - The Idle Timer:** Your live background timer has now started! If you step away from your computer for more than 5 minutes without pausing, the system's **Idle Timer** will detect no mouse/keyboard movement, pause your logged time, and display a yellow warning banner!

## Step 2: Reviewing Your Daily Targets & Pipeline
Before you start dialing, look closely at your **Dashboard**:
1. **Check Your Monthly Targets:** Look at your **Monthly Goal** widget. It includes real-time pacing indicators. If you are behind schedule, it will explicitly warn you. You can also view your **Est. Incentive** earnings based on your successful loan disbursements.
2. **Check Your Daily Call Target:** Look at the "Calls Today" widget. Your standard daily goal is **350 calls**. The progress bar tracks your live dials. If you fall significantly behind the required pace for the hour, the system will turn the widget red and alert you!
3. **Review "Pending Tasks":** Look at the right sidebar widgets. If any tasks or scheduled callbacks are marked **Overdue (Red)**, you must handle those first thing. It also lists exactly who you need to call "Today" and "Tomorrow".
4. **Recent Logins & Performance Charts:** View the dynamic line charts tracking your conversion success rates so you know if your pitch is working.

## Step 3: Start Calling (Two Methods)

### Method A: The Global Auto Dialer (Highly Recommended for Speed)
This is the fastest, "hands-free" way to hit your 350 call target using the Cloud Switchboard.
1. Look at the very top of your screen to find your **Agent Status Bar**.
2. Click the dropdown and change your status from "Offline" to **"Ready for Calls"**.
3. **Keep your hands off the mouse!** The system's algorithm will automatically find the highest priority lead (Sorting logic: Urgent Leads > High Priority > New Leads > Missed Follow-ups > General Leads) and use **Click-To-Call** to dial.
4. **Connection:** Your mobile phone will ring first! Answer it, and the system will immediately connect you to the customer.
5. **Auto-Routing:** The moment the call connects, the CRM will instantly route your screen to that specific customer's profile page so you have all their details right in front of you.
6. **Wrap-up Mode:** When you hang up, a massive **10-second timer** starts on your screen. Use this time to quickly type their outcome (e.g., "Interested") and save. Once the 10 seconds pass, the dialer automatically calls the next person!
   - *Note: If a Manager pauses calling globally, the dialer will pop up a message saying "Calls Paused by Admin" and put you on standby.*

### Method B: The "My Leads" Page (Manual Cherry-picking & Analysis)
If you prefer to manually select who you call, or just want to analyze your pipeline, navigate to the **My Leads** page (`/telecaller/leads`). This page is your personal command center.

#### 1. The Analytics Dashboard (Top 5 Cards)
At the very top of the Leads page, you will see five color-coded metric cards tracking your live progress:
- **Total Assigned (Blue):** The total number of customers currently in your bucket.
- **New Pending (Amber):** Leads that have never been called. This is your "Required Action" list.
- **Contacted (Purple):** Tracks how many leads you've spoken to. Includes a live **% Coverage** progress bar!
- **Logins (Orange):** The number of files you've successfully pushed to a bank.
- **Disbursed (Green):** Displays your ultimate success metric—revenue generated!

#### 2. Lead Filters & Search Tools
Just below the stat cards is the advanced filtering row:
- **Universal Search Bar:** Look up a specific customer by typing their *Name*, *Phone Number*, *Email*, or *Company*.
- **Dropdown Filters:** Filter your 50-item table by **Status** (e.g., only show "Call Backs") or **Priority** (All, Low, Medium, High, Urgent).
- **Data Count:** A small badge shows exactly how many leads match your current filters (e.g., "Showing 50 of 210 results").

#### 3. The Leads Table & Interaction Options
The main table displays your customers in groups of 50. 
- **Sorting:** You can click the column headers to sort your leads by *Loan Amount* or *Date Assigned*.
- **Add Lead:** Did you find a lead on your own through networking? Click the **"+ Add Lead"** button in the top right to manually enter them into your pipeline.
- **One-Click Row Actions:** In the "Contact Options" column, hover over any lead to access quick tooltips:
   - Click the green **Message icon** to instantly open WhatsApp Web.
   - Click the **Phone Missed** icon to execute a "One-Click NR". This instantly marks the lead as "No Response" and auto-schedules a callback for 11:00 AM tomorrow without opening any menus!
- To make a standard call and open the logging modal, click the **Update** button or standard Phone icon, OR click on the Lead Name to open their full **Lead Profile Page**!

## Step 4: The Lead Profile Page (Building Rapport)
When you click on a specific customer or when the Auto-Dialer connects you to someone, you are routed directly to their **Lead Profile Page**. This page is your ultimate weapon while on the phone. It is split into two columns:

### The Left Column (Intelligence & History)
1. **Editable Lead Information:** If the customer tells you they switched jobs or need a "Home" loan instead of a "Personal" loan, you can edit their Company, Designation, Loan Type, and Loan Amount right here. Click **Save Changes** immediately!
2. **The Live Script Engine:** Don't know what to say? The system automatically generates a dynamic reading script for you based on *Your Name*, the *Customer's Name*, and their *Requested Loan Type*. Read it verbatim if you get nervous!
3. **The 4 History Tabs:** Below the script, click through the tabs while talking:
   - **Timeline:** A visual history of everything that has happened to this customer.
   - **Notes:** All past remarks typed by you or others.
   - **Calls:** A log of every previous phone call attempt.
   - **Follow-ups:** Their previously scheduled callbacks.

### The Right Column (Action Commands)
1. **Manager Escalation Button:** Is the customer getting angry or asking for a discount you can't authorize? Hit the red **Escalate to Manager** button to instantly alert your superior.
2. **Live WhatsApp Panel:** Don't pull out your phone! You can chat with the customer on WhatsApp directly through the embedded window on this page.
3. **The Status Updater:** The exact same Call Logging modal is embedded here, so you can drop outcomes (like "Interested" or "Call Back") without leaving the page.
4. **Transfer to KYC Module (The Final Step):** This module is locked by default. It ONLY unlocks when you change the customer's status to **"Login Done"**. Once unlocked, it allows you to select a specific KYC Team Member from a dropdown and formally transfer the file to their department!

## Step 5: The Call Popup & Logging Outcomes in Detail
Whenever you are on an active call (Auto or Manual), a status window pops up on your screen. This window is built for maximum speed.

1. **The Live Call Timer:** At the top of the popup, you will see a pulsing red "Live Recording" timer explicitly tracking your call duration. (If there was a glitch, you can manually override the MM/SS duration text boxes).
2. **During the call:** 
   - Hover over the top-right icons to **Copy their Number**, click the green icon to jump straight into a **WhatsApp Chat**, or click the orange **Missed Call** button to fire off an automated "Sorry we missed you" WhatsApp text instantly.
   - **Quick Notes (Shortcuts!):** Don't type! Click the grey pill badges (e.g., "Busy", "Call Later", "Switch Off", "Docs Pending") and the system will instantly append that text into your Remarks box!
3. **Choose an Outcome:** Once the conversation concludes, you MUST select a new outcome from the dropdown. Each one triggers something special:
   - **Interested / Docs Pending:** Select these and the CRM will **automatically WhatsApp them an official KYC Document Request template**! It will even prompt you to open WhatsApp Web to send a personal follow-up.
   - **Login:** The file was submitted to a bank. You are **strictly required** to enter the precise **Loan Amount**. (Click the +5L, +10L chips to enter amounts in one second).
   - **Disbursed:** The bank approved and paid out the loan! You are **required** to enter the final **Loan Amount** so it hits your incentive tracking. When you save, a green celebration pulse visual effect triggers!
   - **Call Back:** A secondary modal instantly appears. Click **+1 Hr**, **Evening**, or **Tomorrow** to set an exact reminder without opening a calendar picker.
   - **Not Eligible:** You are **required** to select a specific radio button explaining why: "Salary in CASH", "Low CIBIL Score", or "Other". 
   - **NR (No Response):** Automatically overrides and sets your Live Call Timer duration to 0 seconds so your Average Call Duration metrics aren't ruined!
4. **Keyboard Shortcut:** Finished typing your remarks? Just press `Ctrl+Enter` (or `Cmd+Enter` on Mac) to instantly hit the "Submit" button without clicking.
5. **Auto-Load Next Lead:** If you check the "Auto-load next lead" box at the very bottom, clicking **Update Status** will save the outcome, log your call metrics, close the popup, and immediately open the next pending lead on your screen automatically!

## Step 6: Managing Bank Files (The "Logins" Page)
The holy grail of your job is getting files to the bank. When a lead reaches "Login Done" status via the popup, it instantly transfers them to the **Logins Page** (`/telecaller/logins`). You can also manually add logins here.

### 🎯 The Daily Goal Widget
In the top right corner of the page, there is a circular progress tracker. This tracks your **Daily Goal** (the default is 5 logins per day). Watch the circle fill up with indigo color as you successfully submit files!

### 📝 The "New Login" Form (Left Column)
You can manually log a file by using the fixed form on the left side of the screen.
1. **Live Duplicate Checking:** This is critical! As you type the customer's 10-digit mobile number, a spinning wheel appears. The system searches the *entire company database* in real-time.
   - **If Clean:** The box turns green and you can proceed.
   - **If Duplicate:** The box turns bright red, giving you a massive warning: "Duplicate Lead!". It will explicitly tell you *which agent* already logged this number and on *what date*. **The submit button will be permanently disabled**, preventing you from stealing credit or doubling up files!
2. **Submitting:** If the number is clean, select the Target Bank (e.g., HDFC, ICICI, Axis), write any notes regarding documents, and click **Submit Login**.

### 📊 The Logins Table (Right Column)
This is where your files live while the bank's credit team reviews them.
1. **Tabs & Search:** Toggle between "Today's Logins" and "History (Month)". Use the universal search bar to find an old file.
2. **Status Badges:** Files start with an Amber "Pending" badge. 
3. **Taking Action:** Once the bank gives you a decision, you must update the table! Click the ✅ (Approve) button or ❌ (Reject) button to finalize your login.
4. **Editing a File:** Made a typo? Click the "Refresh/Edit" icon on the far right of a row to pull that record back into the left-side form so you can fix it.

### ⚠️ The Morning Reminders (Pending Pop-up)
Do not ignore your pending files! If you open this page and have *any* records stuck in "Pending" from previous days, a massive warning modal will block your screen. It forces you to look at your unresolved files and gives you instant Approval/Rejection action buttons right inside the modal. Clear your queue to dismiss it!

## Step 7: Organization & History (Tasks, Calls, Notes, Chat)
You have several dedicated pages in your sidebar to keep you organized throughout the day:

### Daily Tasks (`/telecaller/tasks`)
This is your master to-do list. Whenever you schedule a "Call Back" in the popup, it generates a Task here.
1. **The 4 Buckets:** At the top of the page, your tasks are visually segmented into four summary cards: **Overdue (Red)**, **Today (Blue)**, **Tomorrow (Green)**, and **Upcoming (Purple)**.
2. **Task Cards:** Each task shows the customer's name, company, and your previous notes.
3. **Quick Actions:** You don't need to open their profile to work! Click the **"Call Now"** button on the card to dial them instantly. Once you've spoken to them, click the **"Mark Done"** button to check it off your list. Or click **"View Lead"** to jump to their profile.

### Call History (`/telecaller/calls`)
Want to know exactly how much time you've spent on the phone? Open your Call History page.
1. **Global Analytics:** The top row of cards shows your all-time **Total Calls**, **Completed Calls**, **Avg Duration** (e.g. 5:30), and your count of **Upcoming** scheduled calls.
2. **Today's Metrics:** The second row isolates your performance for just today: **Today's Calls**, **NR (No Response) Today**, **NI (Not Interested) Today**, and **Today's Total Duration**.
3. **The Call Logs:** Every single call is tracked in a massive list. It displays color-coded badges indicating if the call was "Missed", "Completed", or "Busy", and what the ultimate result was (e.g. "Successful", "Not Interested"). 
4. **Call Again Shortcut:** A quick **"Call Again"** button sits on the right side of every log entry if you need to rapidly redial someone you just spoke to.

### Follow-ups & Reminders (`/telecaller/follow-ups`)
If a customer specifically asks you to call them back, it lands here. This page ensures no lucrative lead falls through the cracks!
1. **The Dual Lists:** The page is split into two visual lists: **Scheduled Follow-ups** (your upcoming responsibilities) and **Overdue Follow-ups** (pulsing red cards demanding immediate attention).
2. **Card Details:** Each reminder shows exactly *who* to call, their company, and precisely *when* (e.g., "Today, 02:30 PM" or "Tomorrow, 10:00 AM"). It also displays the text notes you wrote during your last call context!
3. **Card Actions:** You don't need to hunt for the lead. Right on the reminder card you can:
   - Click **"Call Now"** to instantly dial them via the cloud switchboard.
   - Click **"Complete"** (green checkmark) when the call is successfully finished.
   - OR, if they missed the callback and the card goes overdue, click the dedicated **"Reschedule"** button to bump it to a new time slot without penalties.
4. **Schedule Hub:** You can also use the global "+ Schedule Follow-up" button at the top to proactively create reminders manually.

### My Notes (`/telecaller/notes`)
Think of this as your personal global journal. It's a chronological feed of every single text remark you or your teammates have ever dropped on a lead.
1. **The Analytics Cards:** Track your engagement metrics! See your **Total Notes** ever recorded, how many you've written **This Week**, and exactly how many unique **Leads with Notes** you've documented.
2. **The Global Feed:** Scroll through your history. Every note is automatically given a color-coded identifier badge based on the interaction type:
   - *Blue* = Call, *Green* = Meeting, *Orange* = Follow Up, *Red* = Concern, *Purple* = Opportunity.
3. **Context Jumping:** Reading an old note and want to call them? Click the **"View Lead"** button attached to that specific note to instantly teleport back to their detailed Lead Profile Page!

### Team Chat (`/telecaller/chat`)
Need to ask a manager to approve a special rate, or ask a colleague about an HDFC policy? Open the real-time Team Chat. It works just like Slack/Discord. You can see profile pictures, timestamps, and scroll back through history.

## Step 8: Managing Your Shifts (Attendance & Leave)
Your time is tracked meticulously by the minute. The **Attendance Page** (`/telecaller/attendance`) is a highly advanced portal that shows you exactly where you stand.

### ⏱️ The Attendance Portal Features
1. **The 9-Hour Progress Bar:** At the very top of your "Today's Status" card is a thin strip that acts as a progress bar. It slowly fills up based on a standard 9-hour shift target. Once you hit your required hours, it turns vibrantly Green!
2. **The Visual Timeline:** The page features a vertical timeline mapping your day. It shows exactly when you clicked Check-in, if you are currently on Lunch (displays an "Active" badge), and when you are expected to check out.
3. **The Live Ticker & Idle Tracker:** Watch the massive digital clock tick up your "Total Logged Time". If you stop moving your mouse for 5 minutes, a yellow badge explicitly stating "Idle for 5m" will appear under the clock!
4. **Holiday Banners:** If you log in on a Sunday, a recognized Public Holiday, or a Second Saturday, a massive purple banner with a party popper icon will appear at the top of the page telling you to enjoy your day off!
5. **Taking a Break:** If you are using the Auto-Dialer, change your top Agent Status to **"Lunch Break"**. Then, go to the Attendance page and click the **"Lunch"** button. This explicitly stops your active work timer so your "Hours Worked" metric isn't penalized while you eat! Click "End Break" when you return.
6. **Clocking Out:** When your shift is absolutely over, click the black **"Check Out"** button. A modal will pop up asking for an optional end-of-day summary note. Click Confirm to end your shift.
7. **The Historical Table:** At the bottom of the page is a massive table listing every single day of the month, showing your specific Check-In time, Check-Out time, Total Hours, and Color-Coded Status Badges (Green = Present, Yellow = Late, Red = Absent, Purple = Holiday). Use the "Quick Select" date filters at the top of the page to change the month viewed.

### 🌴 Requesting Time Off (Leave Management)
Need a vacation? Go to the **Leave** page (`/telecaller/leave`) in your sidebar.
1. **Your Entitlement Dashboard:** The top row features 4 cards displaying your exact remaining allowances for the year (e.g., Casual: 12, Sick: 8, Paid: 15, Emergency: 3). Each has a progress bar that dynamically turns Amber or Red as you run out of days.
2. **Submitting a Request:** Click the **"New Request"** button.
   - Choose a category (Sick, Casual, Maternity, etc.).
   - Select your Start Date and End Date.
   - **Smart Validation:** The system instantly calculates the exact number of business days you are requesting (e.g., "Requesting: 3 Days"). If you request more days than you have left, the box turns red with a warning icon and disables the Submit button!
   - Write a reason in the text box and submit.
3. **Application Tracking:** Your request will drop into the History Feed below. It displays an Amber "Pending" badge. Check back later to see if Admin has changed it to an Emerald "Approved" or Red "Rejected" badge. 
4. **Visual Types:** Your history feed makes it easy to skim past applications using icons: Palm trees for Casual, Stethoscopes for Sick leave, and Briefcases for Paid leave.
